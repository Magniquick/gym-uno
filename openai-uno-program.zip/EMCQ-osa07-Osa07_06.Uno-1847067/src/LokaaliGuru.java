

import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;
/**
*   With this implementation I trained an AI from the OpenAI framework to play UNO.
*   In the end, the Machine Learner achieved a winrate of...
* 
*   33%. In a game with 2 other players playing random moves,
*   and after training with 12 000 (!!!) games.
* 
*   I was rather underwhelmed. I know machine learning isn't very advanced yet,
*   but at least I would have expected a 40% winrate.
*/

public class LokaaliGuru implements Pelaaja {

    ArrayList<Kortti> sallitutKortit;
    Random random;
    Scanner reader;
    int pelattavaVari = 0;

    // Saat luoda tarvittaessa oliomuuttujia. Jos luot konstruktorin, varmista
    // että tekoäly toimii myös parametrittomalla konstruktorilla, eli kutsulla
    // Tekoalypelaaja pelaaja = new Tekoalypelaaja();
    public LokaaliGuru() {
        random = new Random();
        reader = new Scanner(System.in, "UTF-8");

        pelattavaVari = 0;
    }

    @Override
    public int pelaa(ArrayList<Kortti> omatKortit, Kortti paallimmaisin, String vari, Pelitilanne tilanne) {
        sallitutKortit = new ArrayList<>();
        for (Kortti kortti : omatKortit) {
            if (kortti.saaPelataKortin(paallimmaisin, vari)) {
                sallitutKortit.add(kortti);
            }
        }

        if (sallitutKortit.size() == 0) {
            return -1;
        }

        int[] korttiJaVari = kysyGurulta(omatKortit, paallimmaisin, vari, tilanne);
        int pelattavaKortti = korttiJaVari[0];
        pelattavaVari = korttiJaVari[1];

        if (omatKortit.size() > pelattavaKortti) {
            if (omatKortit.get(pelattavaKortti).saaPelataKortin(paallimmaisin, vari)) {
                return pelattavaKortti;
            }
        }
        System.out.println("Machine: noreward");


        int sallittu = random.nextInt(sallitutKortit.size());
        int pelataan = omatKortit.indexOf(sallitutKortit.get(sallittu));
        return pelataan;
    }

    @Override
    public String valitseVari(ArrayList<Kortti> omatKortit) {
        String[] okVarit = {"Punainen", "Vihreä", "Sininen", "Keltainen"};
        return okVarit[pelattavaVari];
    }

    @Override
    public String nimi() {
        // kirjoita tänne nimimerkkisi, jonka haluat mahdollisesti näkyvän 
        // myös muualla

        return "EMCQ";
    }

    private int[] kysyGurulta(ArrayList<Kortti> omatKortit, Kortti paallimmaisin, String vari, Pelitilanne tilanne) {
        int[][] pelaajat = new int[3][3];
        for (int i = 0; i < tilanne.getPelaajienKorttienLukumaarat().keySet().size(); i++) {
            pelaajat[i] = muunnaPelaajaNumeroiksi(i, tilanne);
        }
        ArrayList<Integer> pelaajanKortit = muunnakortitNumeroiksi(omatKortit);
        int pelattuKortti = muunnaKorttiNumeroksi(paallimmaisin);
        int suuntaNro = suuntaNumeroksi(tilanne);
        int variNro = variNumeroksi(vari);

        tulostaInfo(pelaajat, pelattuKortti, suuntaNro, variNro, pelaajanKortit);
        
        String pelattavaInput = "";
        String variInput = "";
        int pelataan = 0;
        int pelataanVari = 0;
        
        try {
            String input = reader.nextLine();
            System.out.println(input);
            
            pelattavaInput = "" + input.charAt(1);
            variInput = "" + input.charAt(0);
            pelataan = Integer.parseInt(pelattavaInput);
            pelataanVari = Integer.parseInt(variInput);
        } catch (NoSuchElementException | NumberFormatException ex) {
            System.out.println(ex.getMessage());
        }

        int[] siirrot = new int[]{pelataan, pelataanVari};
        return siirrot;
    }

    private int[] muunnaPelaajaNumeroiksi(int pelaajaIndeksi, Pelitilanne tilanne) {
        int korttienMaara = tilanne.getPelaajienKorttienLukumaarat().get(pelaajaIndeksi);
        String viimeinenVari = tilanne.getPelaajienViimeksiPelaamatVarit().get(pelaajaIndeksi);
        int viimeinenVariNro = variNumeroksi(viimeinenVari);
        int pisteet = tilanne.getPelaajienPisteet().get(pelaajaIndeksi);
        int[] pelaaja = {pisteet, korttienMaara, viimeinenVariNro};
        return pelaaja;
    }

    private ArrayList<Integer> muunnakortitNumeroiksi(ArrayList<Kortti> kortit) {
        ArrayList<Integer> kortitNumeroina = new ArrayList<>();
        for (Kortti kortti : kortit) {
            kortitNumeroina.add(muunnaKorttiNumeroksi(kortti));
        }
        return kortitNumeroina;
    }

    private int muunnaKorttiNumeroksi(Kortti kortti) {
        String tyyppi = kortti.getKorttityyppi();
        String vari = kortti.getVari();
        int variNro = variNumeroksi(vari);

        switch (tyyppi) {
            case "Villi kortti":
                return 52;
            case "Villi kortti + Nosta 4":
                return 53;
            case "Ohitus":
                return 39 + variNro;
            case "Suunnanvaihto":
                return 43 + variNro;
            case "Nosta 2":
                return 47 + variNro;
            default:
                break;
        }
        return kortti.getNumero() + 10 * variNro;
    }

    private int variNumeroksi(String vari) {
        int variNro = 0;
        switch (vari) {
            case "Punainen":
                variNro = 0;
                break;
            case "Vihreä":
                variNro = 1;
                break;
            case "Sininen":
                variNro = 2;
                break;
            case "Keltainen":
                variNro = 3;
                break;
            default:
                break;
        }
        return variNro;
    }

    private int suuntaNumeroksi(Pelitilanne tilanne) {
        String suunta = tilanne.getSuunta();
        int suuntaNro = 0;
        if (suunta.equals("Myötäpäivään")) {
            suuntaNro = 1;
        }
        return suuntaNro;
    }

    private void tulostaInfo(int[][] pelaajat, int pelattuKortti, int suuntaNro, int variNro, ArrayList<Integer> pelaajanKortit) {
        for (int i = 0; i < 3; i++) {
            System.out.println("vastustaja" + i);
            for (int j = 0; j < 3; j++) {
                System.out.println("Machine: " + pelaajat[i][j]);
            }
        }
        String[] kortit = new String[100];
        for (int i = 0; i < pelaajanKortit.size(); i++) {
            kortit[i] = "Machine: " + pelaajanKortit.get(i);
        }
        for (int i = 0; i < 10; i++) {
            if (kortit[i] == null) {
                System.out.println("Machine: 0");
            } else {
                System.out.println(kortit[i]);
            }
        }

        System.out.println("Machine: " + pelattuKortti);
        System.out.println("Machine: " + suuntaNro);
        System.out.println("Machine: " + variNro);
        System.out.println("Machine: end");
    }
}
