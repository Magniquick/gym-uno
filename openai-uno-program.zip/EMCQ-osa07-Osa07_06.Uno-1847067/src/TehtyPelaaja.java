
import java.util.ArrayList;
import java.util.Random;

/**
 *  I couldn't be arsed to finish this implementation that plays according to
 *  certain rules when my AI implementation turned out to be no better than
 *  what doing moves on random would have been.
 */

public class TehtyPelaaja implements Pelaaja {

    private ArrayList<Kortti> sallitutKortit;
    private String enitenVaria;
    private Random random;
    private int suurinUhka;
    private boolean uhkaVoittamassa;
    private String uhanVari;
    private int seuraavaPelaaja;
    private final String[] OKVARIT = {"Punainen", "Vihreä", "Sininen", "Keltainen"};

    public TehtyPelaaja() {
        random = new Random();
        suurinUhka = 0;
        enitenVaria = "Punainen";
        uhanVari = "Punainen";
        seuraavaPelaaja = 0;
        uhkaVoittamassa = false;
        
    }

    @Override
    public int pelaa(ArrayList<Kortti> omatKortit, Kortti paallimmaisin, String vari, Pelitilanne tilanne) {
        paivitaUhka(tilanne);
        paivitaSeuraava(tilanne);
        paivitaOmat(omatKortit);
        uhanVari = tilanne.getPelaajienViimeksiPelaamatVarit().get(suurinUhka);
        
        sallitutKortit = new ArrayList<>();
        for (Kortti kortti : omatKortit) {
            if (kortti.saaPelataKortin(paallimmaisin, vari)) {
                sallitutKortit.add(kortti);
            }
        }

        if (sallitutKortit.isEmpty()) {
            return -1;
        }

        int sallittu = random.nextInt(sallitutKortit.size());
        int pelataan = omatKortit.indexOf(sallitutKortit.get(sallittu));
        return pelataan;
    }

    @Override
    public String valitseVari(ArrayList<Kortti> omatKortit) {
        if (uhkaVoittamassa){
            return uhanVari;
        }
        return enitenVaria;
    }

    private void paivitaUhka(Pelitilanne tilanne) {
        for (Integer pelaaja : tilanne.getPelaajienKorttienLukumaarat().keySet()) {
            if (tilanne.getPelaajienKorttienLukumaarat().get(pelaaja) < 3) {
                suurinUhka = pelaaja;
                uhkaVoittamassa = true;
            }
        }
    }

    private void paivitaSeuraava(Pelitilanne tilanne) {
        if (tilanne.getSuunta().equals("Myötäpäivään")) {
            seuraavaPelaaja = tilanne.getOmaIndeksi() + 1;
        } else {
            seuraavaPelaaja = tilanne.getOmaIndeksi() - 1;
        }
        if (seuraavaPelaaja == -1) {
            seuraavaPelaaja += tilanne.getPelaajienPisteet().keySet().size();
        } else if (seuraavaPelaaja > tilanne.getPelaajienPisteet().keySet().size()) {
            seuraavaPelaaja = 0;
        }
    }

    private void paivitaOmat(ArrayList<Kortti> omatkortit) {
        int[] varit = new int[]{0, 0, 0, 0};
        for (Kortti kortti : omatkortit) {
            if (kortti.getVari().equals(OKVARIT[0])) {
                varit[0]++;
            } else if (kortti.getVari().equals(OKVARIT[1])) {
                varit[1]++;
            } else if (kortti.getVari().equals(OKVARIT[2])) {
                varit[2]++;
            } else if (kortti.getVari().equals(OKVARIT[3])) {
                varit[3]++;
            }
        }
        int suurin = varit[0];
        for (Integer maara : varit) {
            if (maara > suurin) {
                suurin = maara;
            }
        }
        for (int i = 0; i < varit.length; i++) {
            if (varit[i] == suurin) {
                enitenVaria = OKVARIT[i];
            }
        }
    }

    @Override
    public String nimi() {
        return "Tehty";
    }

}
