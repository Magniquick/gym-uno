
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;


/**
 *  Starts of an implementation to use the AI over the internet.
 * 
 */
public class GuruAly implements Pelaaja {

    private ArrayList<Kortti> sallitutKortit;
    private ArrayList<Integer> pelaajienPisteet;
    private Boolean uusiKierrosAlkoi;
    private Boolean minaVoitin;
    private Boolean pelasinSallitun;
    private Random random;
    private Scanner reader;
    private int pelattavaVari = 0;

    // Saat luoda tarvittaessa oliomuuttujia. Jos luot konstruktorin, varmista
    // että tekoäly toimii myös parametrittomalla konstruktorilla, eli kutsulla
    // Tekoalypelaaja pelaaja = new Tekoalypelaaja();
    public GuruAly() {
        random = new Random();
        reader = new Scanner(System.in, "UTF-8");
        pelaajienPisteet = new ArrayList<>();
        uusiKierrosAlkoi = false;
        minaVoitin = false;
        pelasinSallitun = true;
        pelattavaVari = 0;
    }

    @Override
    public int pelaa(ArrayList<Kortti> omatKortit, Kortti paallimmaisin, String vari, Pelitilanne tilanne) {
        sallitutKortit = new ArrayList<>();
        tarkistaKierroksenLoppu(tilanne);
        int pelataan = tarkistaSallitut(omatKortit, paallimmaisin, vari);
        if (pelataan == -1) {
            return pelataan;
        }

        int[] korttiJaVari = kysyGurulta(omatKortit, paallimmaisin, vari, tilanne);
        int pelattavaKortti = korttiJaVari[0];
        pelattavaVari = korttiJaVari[1];

        if (omatKortit.size() > pelattavaKortti) {
            if (omatKortit.get(pelattavaKortti).saaPelataKortin(paallimmaisin, vari)) {
                return pelattavaKortti;
            }
        }
        pelasinSallitun = false;

        int sallittu = random.nextInt(sallitutKortit.size());
        pelataan = omatKortit.indexOf(sallitutKortit.get(sallittu));
        return pelataan;
    }

    @Override
    public String valitseVari(ArrayList<Kortti> omatKortit) {
        String[] okVarit = {"Punainen", "Vihreä", "Sininen", "Keltainen"};
        return okVarit[pelattavaVari];
    }

    @Override
    public String nimi() {
        // kirjoita tänne nimimerkkisi, jonka haluat mahdollisesti näkyvän 
        // myös muualla

        return "EMCQ";
    }

    private int[] kysyGurulta(ArrayList<Kortti> omatKortit, Kortti paallimmaisin, String vari, Pelitilanne tilanne) {
        int[][] pelaajat = new int[3][3];
        for (int i = 0; i < tilanne.getPelaajienKorttienLukumaarat().keySet().size(); i++) {
            pelaajat[i] = muunnaPelaajaNumeroiksi(i, tilanne);
        }
        ArrayList<Integer> pelaajanKortit = muunnakortitNumeroiksi(omatKortit);
        int pelattuKortti = muunnaKorttiNumeroksi(paallimmaisin);
        int suuntaNro = suuntaNumeroksi(tilanne);
        int variNro = variNumeroksi(vari);

        tulostaInfo(pelaajat, pelattuKortti, suuntaNro, variNro, pelaajanKortit);

        String pelattavaInput = "";
        String variInput = "";
        int pelataan = 0;
        int pelataanVari = 0;

//        try {
//            String input = reader.nextLine();
//            System.out.println(input);
//
//            pelattavaInput = "" + input.charAt(1);
//            variInput = "" + input.charAt(0);
//            pelataan = Integer.parseInt(pelattavaInput);
//            pelataanVari = Integer.parseInt(variInput);
//        } catch (NoSuchElementException | NumberFormatException ex) {
//            System.out.println(ex.getMessage());
//        }

//        int[] siirrot = new int[]{pelataan, pelataanVari};
//        pelasinSallitun = true;
        return new int[]{0,0};
    }

    private int[] muunnaPelaajaNumeroiksi(int pelaajaIndeksi, Pelitilanne tilanne) {
        int korttienMaara = tilanne.getPelaajienKorttienLukumaarat().get(pelaajaIndeksi);
        String viimeinenVari = tilanne.getPelaajienViimeksiPelaamatVarit().get(pelaajaIndeksi);
        int viimeinenVariNro = variNumeroksi(viimeinenVari);
        int pisteet = tilanne.getPelaajienPisteet().get(pelaajaIndeksi);
        int[] pelaaja = {pisteet, korttienMaara, viimeinenVariNro};
        return pelaaja;
    }

    private ArrayList<Integer> muunnakortitNumeroiksi(ArrayList<Kortti> kortit) {
        ArrayList<Integer> kortitNumeroina = new ArrayList<>();
        for (Kortti kortti : kortit) {
            kortitNumeroina.add(muunnaKorttiNumeroksi(kortti));
        }
        return kortitNumeroina;
    }

    private int muunnaKorttiNumeroksi(Kortti kortti) {
        String tyyppi = kortti.getKorttityyppi();
        String vari = kortti.getVari();
        int variNro = variNumeroksi(vari);

        switch (tyyppi) {
            case "Villi kortti":
                return 52;
            case "Villi kortti + Nosta 4":
                return 53;
            case "Ohitus":
                return 39 + variNro;
            case "Suunnanvaihto":
                return 43 + variNro;
            case "Nosta 2":
                return 47 + variNro;
            default:
                break;
        }
        return kortti.getNumero() + 10 * variNro;
    }

    private int variNumeroksi(String vari) {
        int variNro = 0;
        switch (vari) {
            case "Punainen":
                variNro = 0;
                break;
            case "Vihreä":
                variNro = 1;
                break;
            case "Sininen":
                variNro = 2;
                break;
            case "Keltainen":
                variNro = 3;
                break;
            default:
                break;
        }
        return variNro;
    }

    private int suuntaNumeroksi(Pelitilanne tilanne) {
        String suunta = tilanne.getSuunta();
        int suuntaNro = 0;
        if (suunta.equals("Myötäpäivään")) {
            suuntaNro = 1;
        }
        return suuntaNro;
    }

    private void tulostaInfo(int[][] pelaajat, int pelattuKortti, int suuntaNro, int variNro, ArrayList<Integer> pelaajanKortit) {
        ArrayList<String> lahetettavat = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                lahetettavat.add(String.valueOf(pelaajat[i][j]));
            }
        }
        String[] kortit = new String[100];
        for (int i = 0; i < pelaajanKortit.size(); i++) {
            kortit[i] = String.valueOf(pelaajanKortit.get(i));
        }
        for (int i = 0; i < 10; i++) {
            if (kortit[i] == null) {
                lahetettavat.add("0");
            } else {
                lahetettavat.add(kortit[i]);
            }
        }

        lahetettavat.add(String.valueOf(pelattuKortti));
        lahetettavat.add(String.valueOf(suuntaNro));
        lahetettavat.add(String.valueOf(variNro));
        //laheta(lahetettavat);
    }

    private void tarkistaKierroksenLoppu(Pelitilanne tilanne) {
        uusiKierrosAlkoi = false;
        ArrayList<Integer> uudetPisteet = new ArrayList<>();
        for (int i = 0; i < tilanne.getPelaajienPisteet().size(); i++) {
            int uusiPiste = tilanne.getPelaajienPisteet().get(i);
            uudetPisteet.add(uusiPiste);
            if (uusiPiste != pelaajienPisteet.get(i)) {
                uusiKierrosAlkoi = true;
            }
        }
        pelaajienPisteet = uudetPisteet;
    }

    private int tarkistaSallitut(ArrayList<Kortti> omatKortit, Kortti paallimmaisin, String vari) {
        for (Kortti kortti : omatKortit) {
            if (kortti.saaPelataKortin(paallimmaisin, vari)) {
                sallitutKortit.add(kortti);
            }
        }

        if (sallitutKortit.isEmpty()) {
            return -1;
        }
        return 0;
    }

}
