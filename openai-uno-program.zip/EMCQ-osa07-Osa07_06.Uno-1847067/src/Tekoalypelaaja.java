
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author emcq
 */
public class Tekoalypelaaja implements Pelaaja {

    private ArrayList<Kortti> sallitutKortit;
    private Random random;
    private Scanner reader;

    // Saat luoda tarvittaessa oliomuuttujia. Jos luot konstruktorin, varmista
    // että tekoäly toimii myös parametrittomalla konstruktorilla, eli kutsulla
    // Tekoalypelaaja pelaaja = new Tekoalypelaaja();
    public Tekoalypelaaja() {
        random = new Random();
        reader = new Scanner(System.in);
    }

    @Override
    public int pelaa(ArrayList<Kortti> omatKortit, Kortti paallimmaisin, String vari, Pelitilanne tilanne) {
        sallitutKortit = new ArrayList<>();
        for (Kortti kortti : omatKortit) {
            if (kortti.saaPelataKortin(paallimmaisin, vari)) {
                sallitutKortit.add(kortti);
            }
        }

        if (sallitutKortit.isEmpty()) {
            return -1;
        }

        int sallittu = random.nextInt(sallitutKortit.size());
        int pelataan = omatKortit.indexOf(sallitutKortit.get(sallittu));
        return pelataan;
    }

    @Override
    public String valitseVari(ArrayList<Kortti> omatKortit) {
        String[] okVarit = {"Punainen", "Vihreä", "Sininen", "Keltainen"};
        return okVarit[random.nextInt(4)];
    }

    @Override
    public String nimi() {
        // kirjoita tänne nimimerkkisi, jonka haluat mahdollisesti näkyvän 
        // myös muualla

        return "RANDOM";
    }
}
